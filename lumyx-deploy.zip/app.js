const STORE_KEY = "lumyx-mvp";
const SESSION_KEY = "lumyx-session";
const AUTH_SESSION_KEY = "lumyx-auth-session";
const config = window.LUMYX_CONFIG || {};

const activityTypes = [
    "reunião",
  "atendimento institucional",
  "visita técnica",
  "matriciamento",
  "capacitação",
  "supervisão",
  "ação territorial",
  "ação intersetorial",
  "planejamento",
  "evento",
  "demanda judicial",
  "relatório",
  "reunião de rede",
    "alinhamento operacional",
    "automação de relatório",
    "rotina administrativa",
  "outro",
];

const state = {
  calendarMode: "month",
  activities: [],
  units: [],
  recordings: [],
  reports: [],
  demands: [],
  mediaRecorder: null,
  audioChunks: [],
  currentAudio: "",
  cloudReady: false,
  organizationId: "",
  userId: "",
};

const $ = (id) => document.getElementById(id);
const today = () => new Date().toISOString().slice(0, 10);
const uid = (prefix) => `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2)}`;

window.addEventListener("error", (event) => {
  console.warn("LUMYX recovered from client error:", event.message);
});

window.addEventListener("unhandledrejection", (event) => {
  console.warn("LUMYX recovered from async error:", event.reason?.message || event.reason);
  event.preventDefault();
});

function isSupabaseConfigured() {
  return Boolean(config.supabaseUrl && config.supabaseAnonKey);
}

function getAuthSession() {
  try {
    const raw = localStorage.getItem(AUTH_SESSION_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function hasActiveSession() {
  const session = getAuthSession();
  if (session?.expires_at && session.expires_at * 1000 > Date.now()) return true;
  return localStorage.getItem(SESSION_KEY) === "active";
}

function clearCloudSession() {
  localStorage.removeItem(AUTH_SESSION_KEY);
  if (localStorage.getItem(SESSION_KEY) === "cloud") {
    localStorage.removeItem(SESSION_KEY);
  }
  state.cloudReady = false;
  state.organizationId = "";
  state.userId = "";
}

async function supabaseSignIn(email, password) {
  const response = await fetch(`${config.supabaseUrl}/auth/v1/token?grant_type=password`, {
    method: "POST",
    headers: {
      apikey: config.supabaseAnonKey,
      Authorization: `Bearer ${config.supabaseAnonKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ email, password }),
  });

  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(payload.error_description || payload.msg || payload.error || "Login Supabase nao autorizado.");
  }
  localStorage.setItem(AUTH_SESSION_KEY, JSON.stringify(payload));
  localStorage.setItem(SESSION_KEY, "cloud");
  return payload;
}

function canUseDemoLogin(email, password) {
  return email === (config.demoEmail || "admin@lumyx.local") && password === (config.demoPassword || "123456");
}

function dataUrlToBlob(dataUrl) {
  const [metadata, base64] = dataUrl.split(",");
  const mime = metadata.match(/data:(.*?);base64/)?.[1] || "audio/webm";
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) {
    bytes[index] = binary.charCodeAt(index);
  }
  return new Blob([bytes], { type: mime });
}

async function transcribeCurrentAudioWithAi() {
  if (!state.currentAudio && !$("audioPlayer").src) {
    alert("Grave um audio antes de transcrever com IA.");
    return;
  }
  if (!isSupabaseConfigured()) {
    alert("Supabase nao configurado. Use a transcricao manual por enquanto.");
    return;
  }

  const button = $("transcribeBtn");
  const originalText = button.textContent;
  button.textContent = "Transcrevendo...";
  button.disabled = true;

  try {
    const audioSource = state.currentAudio || $("audioPlayer").src;
    const audioBlob = dataUrlToBlob(audioSource);
    const form = new FormData();
    form.append("audio", audioBlob, "lumyx-audio.webm");
    form.append("context", $("recordingTranscript").value || "");

    const response = await fetch(`${config.supabaseUrl}/functions/v1/transcribe-audio`, {
      method: "POST",
      headers: {
        apikey: config.supabaseAnonKey,
        Authorization: `Bearer ${config.supabaseAnonKey}`,
      },
      body: form,
    });

    const payload = await response.json().catch(() => ({}));
    if (!response.ok || payload.error) {
      throw new Error(payload.error || "Nao foi possivel transcrever com IA.");
    }

    $("recordingTranscript").value = payload.transcript || "";
    $("recordingSummary").value = payload.summary || buildRecordingSummary();
  } catch (error) {
    alert(`A IA ainda nao respondeu: ${error.message}\n\nSe a funcao ainda nao foi publicada no Supabase, use a transcricao manual por enquanto.`);
  } finally {
    button.textContent = originalText;
    button.disabled = false;
  }
}

function authHeaders() {
  const session = getAuthSession();
  const token = session?.access_token || config.supabaseAnonKey;
  return {
    apikey: config.supabaseAnonKey,
    Authorization: `Bearer ${token}`,
    "Content-Type": "application/json",
  };
}

async function supabaseRequest(path, options = {}) {
  if (!isSupabaseConfigured()) throw new Error("Supabase nao configurado.");
  const response = await fetch(`${config.supabaseUrl}/rest/v1/${path}`, {
    ...options,
    headers: {
      ...authHeaders(),
      Prefer: options.prefer || "return=representation",
      ...(options.headers || {}),
    },
  });
  const text = await response.text();
  const payload = text ? JSON.parse(text) : null;
  if (!response.ok) {
    throw new Error(payload?.message || payload?.hint || payload?.details || "Erro Supabase.");
  }
  return payload;
}

async function ensureCloudWorkspace() {
  const session = getAuthSession();
  const user = session?.user;
  if (!user?.id) return false;

  state.userId = user.id;
  let profile = await supabaseRequest(`profiles?select=*&id=eq.${user.id}`).then((rows) => rows[0]).catch(() => null);

  if (!profile?.organization_id) {
    const organization = await supabaseRequest("organizations", {
      method: "POST",
      body: JSON.stringify({
        name: "LUMYX Workspace",
        slug: `lumyx-${user.id.slice(0, 8)}`,
      }),
    }).then((rows) => rows[0]);

    profile = await supabaseRequest("profiles", {
      method: "POST",
      body: JSON.stringify({
        id: user.id,
        organization_id: organization.id,
        name: user.email?.split("@")[0] || "Usuario LUMYX",
        email: user.email || "",
        role: "owner",
        position: "Administrador",
        department: "Operacoes",
      }),
    }).then((rows) => rows[0]);
  }

  state.organizationId = profile.organization_id;
  state.cloudReady = true;
  await syncDefaultUnitsToCloud();
  await loadCloudState();
  return true;
}

function withCloudIds(record) {
  return {
    ...record,
    organization_id: state.organizationId,
    user_id: state.userId,
  };
}

async function syncDefaultUnitsToCloud() {
  if (!state.cloudReady) return;
  const existing = await supabaseRequest(`units?select=id&organization_id=eq.${state.organizationId}`);
  if (existing.length) return;
  const units = defaultData().units.map((unit) => ({
    organization_id: state.organizationId,
    name: unit.name,
    type: unit.type,
    address: unit.address,
    contact: unit.contact,
    responsible: unit.responsible,
    observations: unit.observations,
  }));
  await supabaseRequest("units", { method: "POST", body: JSON.stringify(units) });
}

async function loadCloudState() {
  if (!state.cloudReady) return;
  const [units, activities, recordings, reports, demands] = await Promise.all([
    supabaseRequest(`units?select=*&organization_id=eq.${state.organizationId}&order=created_at.asc`),
    supabaseRequest(`activities?select=*&organization_id=eq.${state.organizationId}&order=date.desc`),
    supabaseRequest(`recordings?select=*&organization_id=eq.${state.organizationId}&order=created_at.desc`),
    supabaseRequest(`reports?select=*&organization_id=eq.${state.organizationId}&order=created_at.desc`),
    supabaseRequest(`demands?select=*&organization_id=eq.${state.organizationId}&order=created_at.desc`),
  ]);
  state.units = units;
  state.activities = activities;
  state.recordings = recordings;
  state.reports = reports;
  state.demands = demands;
  renderAll();
}

async function saveCloudActivity(activity) {
  if (!state.cloudReady) return;
  const payload = withCloudIds(activity);
  await supabaseRequest("activities", {
    method: "POST",
    headers: { Prefer: "resolution=merge-duplicates,return=representation" },
    body: JSON.stringify(payload),
  });
}

async function saveCloudRecording(recording) {
  if (!state.cloudReady) return;
  await supabaseRequest("recordings", {
    method: "POST",
    body: JSON.stringify(withCloudIds(recording)),
  });
}

async function saveCloudReport(report) {
  if (!state.cloudReady) return;
  await supabaseRequest("reports", {
    method: "POST",
    body: JSON.stringify(withCloudIds(report)),
  });
}

function defaultData() {
  const date = today();
  const units = [
    { id: "unit-ops", name: "Operações", type: "Gestão", address: "", contact: "", responsible: "", observations: "Área central para acompanhamento de rotinas e entregas." },
    { id: "unit-admin", name: "Administrativo", type: "Backoffice", address: "", contact: "", responsible: "", observations: "Demandas internas, documentos e fluxos de apoio." },
    { id: "unit-projects", name: "Projetos", type: "Planejamento", address: "", contact: "", responsible: "", observations: "Iniciativas, reuniões e acompanhamento de prazos." },
    { id: "unit-client", name: "Clientes / Parceiros", type: "Relacionamento", address: "", contact: "", responsible: "", observations: "Interações externas e registros institucionais." },
    { id: "unit-ai", name: "Automação e IA", type: "Tecnologia", address: "", contact: "", responsible: "", observations: "Resumos, documentos e automações futuras." },
    { id: "unit-finance", name: "Financeiro", type: "Gestão", address: "", contact: "", responsible: "", observations: "" },
  ];

  return {
    units,
    activities: [
      {
        id: uid("act"),
        title: "Reunião de alinhamento operacional",
        date,
        start_time: "09:00",
        end_time: "10:30",
        location: "Sala executiva / online",
        unit_id: "unit-ops",
        type: "reunião de rede",
        priority: "alta",
        status: "planejada",
        participants: "Gestão; operação; administrativo",
        objective: "Alinhar prioridades, responsáveis e entregas da semana.",
        description: "Reunião inicial para organizar a rotina operacional.",
        main_points: "Priorização de tarefas; prazos; geração de relatório; próximos passos.",
        referrals: "Definir responsáveis; revisar pendências; gerar relatório executivo.",
        responsible_people: "Gestão operacional; administrativo.",
        deadlines: "Até a próxima sexta-feira.",
        observations: "Todo texto gerado por IA deve ser revisado antes do envio.",
        ai_summary: "",
        attachment_name: "",
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
    ],
    recordings: [],
    reports: [],
    demands: [
      {
        id: uid("dem"),
        title: "Organizar resposta de demanda estratégica",
        origin: "Diretoria",
        date_received: date,
        deadline: date,
        responsible: "Gestão operacional",
        status: "em análise",
        priority: "média",
        description: "Mapear informações, próximos passos e documentos necessários.",
        referrals: "Registrar reunião e consolidar relatório executivo.",
        documents: "",
      },
    ],
  };
}

function loadState() {
  const stored = localStorage.getItem(STORE_KEY);
  const data = stored ? JSON.parse(stored) : defaultData();
  state.activities = data.activities || [];
  state.units = data.units || [];
  state.recordings = data.recordings || [];
  state.reports = data.reports || [];
  state.demands = data.demands || [];
  persist();
}

function persist() {
  localStorage.setItem(STORE_KEY, JSON.stringify({
    activities: state.activities,
    units: state.units,
    recordings: state.recordings,
    reports: state.reports,
    demands: state.demands,
  }));
}

function init() {
  loadState();
  hydrateOptions();
  bindEvents();
  resetActivityForm();
  renderAll();
  registerServiceWorker();
  applyLaunchShortcut();
  if (hasActiveSession()) showAppAndSync();
  setTimeout(() => $("loadingScreen")?.classList.add("hidden"), 450);
}

function registerServiceWorker() {
  if (!("serviceWorker" in navigator)) return;
  navigator.serviceWorker
    .register("sw.js")
    .then((registration) => registration.update())
    .catch((error) => {
      console.warn("Service worker unavailable:", error.message);
    });
}

function applyLaunchShortcut() {
  const shortcut = new URLSearchParams(window.location.search).get("shortcut");
  if (!shortcut) return;
  window.history.replaceState({}, "", window.location.pathname);
  setTimeout(() => handleShortcut(shortcut), 100);
}

function showApp() {
  $("loginScreen").classList.add("hidden");
  $("appShell").classList.remove("hidden");
}

async function showAppAndSync() {
  showApp();
  const session = getAuthSession();
  if (!session?.access_token) return;
  try {
    await ensureCloudWorkspace();
  } catch (error) {
    clearCloudSession();
    console.warn("LUMYX cloud sync unavailable:", error.message);
    alert(`Login feito, mas ainda nao consegui sincronizar com o banco Supabase.\n\nDetalhe: ${error.message}\n\nO app continuara funcionando no modo local.`);
  }
}

function setView(viewId) {
  document.querySelectorAll(".view").forEach((view) => view.classList.toggle("active", view.id === viewId));
  document.querySelectorAll(".nav-item").forEach((item) => item.classList.toggle("active", item.dataset.view === viewId));
  const label = document.querySelector(`[data-view="${viewId}"] span`)?.textContent || "Dashboard";
  $("pageTitle").textContent = label;
}

function hydrateOptions() {
  $("type").innerHTML = activityTypes.map((type) => `<option>${type}</option>`).join("");
  $("reportTypeFilter").innerHTML += activityTypes.map((type) => `<option value="${type}">${type}</option>`).join("");
  renderUnitOptions();
}

function renderUnitOptions() {
  const options = state.units.map((unit) => `<option value="${unit.id}">${unit.name}</option>`).join("");
  $("unitId").innerHTML = options;
  $("recordingActivitySelect").innerHTML = state.activities.map((activity) => `<option value="${activity.id}">${formatDate(activity.date)} - ${activity.title}</option>`).join("");
}

function renderAll() {
  renderDashboard();
  renderActivities();
  renderCalendar();
  renderRecordings();
  renderReports();
  renderUnits();
  renderDemands();
  renderIndicators();
  renderUnitOptions();
}

function renderDashboard() {
  const now = new Date();
  const thisMonth = state.activities.filter((activity) => {
    const d = new Date(`${activity.date}T00:00`);
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  });
  const todayActivities = state.activities.filter((activity) => activity.date === today());
  const pending = state.activities.filter((activity) => ["pendente", "em andamento", "planejada"].includes(activity.status));

  $("mToday").textContent = todayActivities.length;
  $("mPending").textContent = pending.length;
  $("mReports").textContent = state.reports.length;
  $("mRecordings").textContent = state.recordings.filter((rec) => rec.status !== "transcrita").length;
  $("mMonth").textContent = thisMonth.length;
  $("mUnits").textContent = new Set(state.activities.map((a) => a.unit_id).filter(Boolean)).size || state.units.length;

  renderStack("todayList", todayActivities.map(activityCard));
  renderStack("pendingList", pending.slice(0, 6).map(activityCard));
}

function renderActivities() {
  const query = $("activitySearch")?.value?.toLowerCase() || "";
  const list = state.activities
    .filter((activity) => searchable(activity).includes(query))
    .sort((a, b) => `${b.date}${b.start_time}`.localeCompare(`${a.date}${a.start_time}`));
  renderStack("activityList", list.map(activityCard));
}

function renderCalendar() {
  const query = $("agendaSearch")?.value?.toLowerCase() || "";
  const status = $("agendaStatusFilter")?.value || "todos";
  const list = state.activities.filter((activity) => {
    const statusOk = status === "todos" || activity.status === status;
    return statusOk && searchable(activity).includes(query);
  });

  if (state.calendarMode === "day") {
    renderStack("calendarShell", list.filter((activity) => activity.date === today()).map(activityCard));
    return;
  }

  if (state.calendarMode === "week") {
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    const end = new Date(start);
    end.setDate(start.getDate() + 7);
    const week = list.filter((activity) => {
      const date = new Date(`${activity.date}T00:00`);
      return date >= start && date <= end;
    });
    renderStack("calendarShell", week.map(activityCard));
    return;
  }

  const days = daysInCurrentMonth();
  $("calendarShell").innerHTML = `<div class="calendar-grid">${days.map((day) => calendarDay(day, list)).join("")}</div>`;
}

function calendarDay(day, activities) {
  const date = day.toISOString().slice(0, 10);
  const events = activities.filter((activity) => activity.date === date).slice(0, 3);
  return `
    <article class="calendar-day">
      <strong>${day.getDate()}</strong>
      ${events.map((event) => `<div class="calendar-event">${event.start_time} ${escapeHtml(event.title)}</div>`).join("")}
    </article>
  `;
}

function daysInCurrentMonth() {
  const now = new Date();
  const total = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  return Array.from({ length: total }, (_, i) => new Date(now.getFullYear(), now.getMonth(), i + 1));
}

function renderRecordings() {
  renderStack("recordingList", state.recordings.map((recording) => {
    const activity = state.activities.find((item) => item.id === recording.activity_id);
    const card = document.createElement("article");
    card.className = `item-card ${recording.status === "pendente" ? "pendente" : ""}`;
    card.innerHTML = `
      <div class="item-top">
        <div>
          <div class="item-title">${escapeHtml(activity?.title || "Gravação sem atividade")}</div>
          <div class="item-meta">${formatDate(recording.created_at.slice(0, 10))} - ${recording.status}</div>
        </div>
        <span class="pill">${recording.status}</span>
      </div>
      ${recording.audio_url ? `<audio controls src="${recording.audio_url}"></audio>` : ""}
      <div class="item-actions">
        <button class="mini-button" data-action="open-recording" data-id="${recording.id}" type="button">Abrir</button>
      </div>
    `;
    return card;
  }));
}

function renderReports() {
  renderStack("reportHistory", state.reports.map((report) => {
    const card = document.createElement("article");
    card.className = "item-card";
    card.innerHTML = `
      <div class="item-top">
        <div>
          <div class="item-title">${escapeHtml(report.title)}</div>
          <div class="item-meta">${formatDate(report.period_start)} a ${formatDate(report.period_end)} - ${report.type}</div>
        </div>
        <span class="pill">salvo</span>
      </div>
      <div class="item-actions">
        <button class="mini-button" data-action="open-report" data-id="${report.id}" type="button">Abrir</button>
      </div>
    `;
    return card;
  }));
}

function renderUnits() {
  $("unitList").innerHTML = state.units.map((unit) => `
    <article class="unit-card">
      <h3>${escapeHtml(unit.name)}</h3>
      <p class="item-meta">${escapeHtml(unit.type)}</p>
      <p class="item-meta">${escapeHtml(unit.observations || "Sem observações cadastradas.")}</p>
    </article>
  `).join("");
}

function renderDemands() {
  $("demandList").innerHTML = state.demands.map((demand) => `
    <article class="demand-card">
      <div class="item-top">
        <div>
          <div class="item-title">${escapeHtml(demand.title)}</div>
          <div class="item-meta">Origem: ${escapeHtml(demand.origin)} - Prazo: ${formatDate(demand.deadline)}</div>
          <div class="item-meta">${escapeHtml(demand.description)}</div>
        </div>
        <span class="pill">${escapeHtml(demand.status)}</span>
      </div>
    </article>
  `).join("");
}

function renderIndicators() {
  const typeCounts = countBy(state.activities, "type");
  const statusCounts = countBy(state.activities, "status");
  $("typeChart").innerHTML = bars(typeCounts);
  $("statusChart").innerHTML = bars(statusCounts);
}

function bars(counts) {
  const max = Math.max(1, ...Object.values(counts));
  return Object.entries(counts).map(([label, value]) => `
    <div class="bar">
      <div class="bar-row"><span>${escapeHtml(label)}</span><strong>${value}</strong></div>
      <div class="bar-fill"><span style="width:${(value / max) * 100}%"></span></div>
    </div>
  `).join("") || `<div class="empty-state"><strong>Sem dados</strong><span>Crie atividades para gerar indicadores.</span></div>`;
}

function countBy(list, key) {
  return list.reduce((acc, item) => {
    acc[item[key]] = (acc[item[key]] || 0) + 1;
    return acc;
  }, {});
}

function activityCard(activity) {
  const unit = state.units.find((item) => item.id === activity.unit_id);
  const card = document.createElement("article");
  card.className = `item-card ${activity.priority} ${activity.status}`;
  card.innerHTML = `
    <div class="item-top">
      <div>
        <div class="item-title">${escapeHtml(activity.title)}</div>
        <div class="item-meta">${formatDate(activity.date)} - ${activity.start_time || "--:--"} a ${activity.end_time || "--:--"} - ${escapeHtml(activity.location || "Local não informado")}</div>
        <div class="item-meta">${escapeHtml(unit?.name || "Unidade não vinculada")} - ${escapeHtml(activity.type)}</div>
      </div>
      <span class="pill">${escapeHtml(activity.status)}</span>
    </div>
    <div class="item-actions">
      <button class="mini-button" data-action="edit-activity" data-id="${activity.id}" type="button">Editar</button>
      <button class="mini-button" data-action="summarize-activity" data-id="${activity.id}" type="button">Resumo</button>
      <button class="mini-button" data-action="activity-report" data-id="${activity.id}" type="button">Relatório</button>
    </div>
  `;
  return card;
}

function renderStack(id, nodes) {
  const container = $(id);
  container.innerHTML = "";
  if (!nodes.length) {
    container.appendChild($("emptyTemplate").content.cloneNode(true));
    return;
  }
  nodes.forEach((node) => container.appendChild(node));
}

function searchable(activity) {
  return Object.values(activity).join(" ").toLowerCase();
}

function bindEvents() {
  $("loginForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const email = $("loginEmail").value.trim();
    const password = $("loginPassword").value;
    const submitButton = $("loginForm").querySelector("button[type='submit']");
    const originalText = submitButton.textContent;
    submitButton.textContent = "Entrando...";
    submitButton.disabled = true;

    try {
      if (isSupabaseConfigured() && !canUseDemoLogin(email, password)) {
        await supabaseSignIn(email, password);
      } else {
        localStorage.setItem(SESSION_KEY, "active");
      }
      await showAppAndSync();
    } catch (error) {
      alert(`Nao foi possivel entrar no Supabase: ${error.message}\n\nCrie o usuario no Supabase Auth ou use o login demo admin@lumyx.local / 123456 por enquanto.`);
    } finally {
      submitButton.textContent = originalText;
      submitButton.disabled = false;
    }
  });

  document.querySelector(".nav").addEventListener("click", (event) => {
    const button = event.target.closest("[data-view]");
    if (button) setView(button.dataset.view);
  });

  document.addEventListener("click", (event) => {
    const quickNew = event.target.closest("#quickNewBtn");
    if (quickNew) {
      event.preventDefault();
      handleShortcut("activity");
      return;
    }

    const exportData = event.target.closest("#exportDataBtn");
    if (exportData) {
      event.preventDefault();
      exportData();
      return;
    }

    const shortcut = event.target.closest("[data-shortcut]");
    if (shortcut) {
      event.preventDefault();
      handleShortcut(shortcut.dataset.shortcut);
      return;
    }

    const action = event.target.closest("[data-action]");
    if (action) {
      event.preventDefault();
      handleAction(action.dataset.action, action.dataset.id);
    }
  }, true);

  $("quickNewBtn").addEventListener("click", () => handleShortcut("activity"));
  $("activityForm").addEventListener("submit", saveActivity);
  $("clearActivityBtn").addEventListener("click", resetActivityForm);
  $("summaryBtn").addEventListener("click", () => $("aiSummary").value = buildActivitySummary(formToActivity()));
  $("recordFromFormBtn").addEventListener("click", () => setView("gravacoes"));
  $("activitySearch").addEventListener("input", renderActivities);
  $("agendaSearch").addEventListener("input", renderCalendar);
  $("agendaStatusFilter").addEventListener("change", renderCalendar);

  document.querySelectorAll("[data-calendar-mode]").forEach((button) => {
    button.addEventListener("click", () => {
      state.calendarMode = button.dataset.calendarMode;
      document.querySelectorAll("[data-calendar-mode]").forEach((item) => item.classList.toggle("active", item === button));
      renderCalendar();
    });
  });

  $("startRecordBtn").addEventListener("click", startRecording);
  $("recordBtn").addEventListener("click", startRecording);
  $("pauseRecordBtn").addEventListener("click", pauseRecording);
  $("stopRecordBtn").addEventListener("click", stopRecording);
  $("transcribeBtn").addEventListener("click", transcribeCurrentAudioWithAi);
  $("recordingSummaryBtn").addEventListener("click", () => $("recordingSummary").value = buildRecordingSummary());
  $("saveRecordingBtn").addEventListener("click", saveRecording);

  $("generateReportBtn").addEventListener("click", () => $("reportOutput").value = buildInstitutionalReport());
  $("copyReportBtn").addEventListener("click", copyReport);
  $("saveReportBtn").addEventListener("click", saveReport);
  $("exportPdfBtn").addEventListener("click", () => window.print());

  $("exportDataBtn").addEventListener("click", exportData);
  $("importDataInput").addEventListener("change", importData);
  $("logoInput").addEventListener("change", updateLogo);
}

function handleShortcut(shortcut) {
  if (shortcut === "activity") {
    resetActivityForm();
    setView("atividades");
  }
  if (shortcut === "recording") setView("gravacoes");
  if (shortcut === "report") setView("relatorios");
  if (shortcut === "agenda") setView("agenda");
}

function handleAction(action, id) {
  if (action === "edit-activity") {
    const activity = state.activities.find((item) => item.id === id);
    if (activity) fillActivityForm(activity);
  }
  if (action === "summarize-activity") {
    const activity = state.activities.find((item) => item.id === id);
    if (activity) {
      activity.ai_summary = buildActivitySummary(activity);
      persist();
      fillActivityForm(activity);
    }
  }
  if (action === "activity-report") {
    const activity = state.activities.find((item) => item.id === id);
    if (activity) {
      $("reportOutput").value = buildSingleActivityReport(activity);
      setView("relatorios");
    }
  }
  if (action === "open-recording") {
    const recording = state.recordings.find((item) => item.id === id);
    if (recording) fillRecording(recording);
  }
  if (action === "open-report") {
    const report = state.reports.find((item) => item.id === id);
    if (report) {
      $("reportOutput").value = report.content;
      setView("relatorios");
    }
  }
}

function formToActivity() {
  const existing = state.activities.find((item) => item.id === $("activityId").value);
  return {
    id: $("activityId").value || uid("act"),
    title: $("title").value.trim(),
    date: $("date").value,
    start_time: $("startTime").value,
    end_time: $("endTime").value,
    location: $("location").value.trim(),
    unit_id: $("unitId").value,
    type: $("type").value,
    priority: $("priority").value,
    status: $("status").value,
    participants: $("participants").value.trim(),
    objective: $("objective").value.trim(),
    description: $("description").value.trim(),
    main_points: $("mainPoints").value.trim(),
    referrals: $("referrals").value.trim(),
    responsible_people: $("responsiblePeople").value.trim(),
    deadlines: $("deadlines").value.trim(),
    observations: $("observations").value.trim(),
    ai_summary: $("aiSummary").value.trim(),
    attachment_name: $("attachment").files[0]?.name || existing?.attachment_name || "",
    created_at: existing?.created_at || new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };
}

async function saveActivity(event) {
  event.preventDefault();
  const activity = formToActivity();
  const index = state.activities.findIndex((item) => item.id === activity.id);
  if (index >= 0) state.activities[index] = activity;
  else state.activities.push(activity);
  persist();
  try {
    await saveCloudActivity(activity);
  } catch (error) {
    console.warn("Activity saved locally only:", error.message);
  }
  renderAll();
  resetActivityForm();
}

function fillActivityForm(activity) {
  $("activityId").value = activity.id;
  $("title").value = activity.title || "";
  $("date").value = activity.date || today();
  $("startTime").value = activity.start_time || "08:00";
  $("endTime").value = activity.end_time || "";
  $("location").value = activity.location || "";
  $("unitId").value = activity.unit_id || state.units[0]?.id || "";
  $("type").value = activity.type || activityTypes[0];
  $("priority").value = activity.priority || "média";
  $("status").value = activity.status || "planejada";
  $("participants").value = activity.participants || "";
  $("objective").value = activity.objective || "";
  $("description").value = activity.description || "";
  $("mainPoints").value = activity.main_points || "";
  $("referrals").value = activity.referrals || "";
  $("responsiblePeople").value = activity.responsible_people || "";
  $("deadlines").value = activity.deadlines || "";
  $("observations").value = activity.observations || "";
  $("aiSummary").value = activity.ai_summary || "";
  $("formState").textContent = "Editando atividade";
  setView("atividades");
}

function resetActivityForm() {
  $("activityForm").reset();
  $("activityId").value = "";
  $("date").value = today();
  $("startTime").value = "08:00";
  $("endTime").value = "09:00";
  $("priority").value = "média";
  $("status").value = "planejada";
  $("type").value = "reunião";
  $("unitId").value = state.units[0]?.id || "";
  $("formState").textContent = "Novo registro";
}

async function startRecording() {
  if (!navigator.mediaDevices?.getUserMedia) {
    alert("Este navegador não liberou gravação. Você ainda pode escrever a memória manualmente.");
    return;
  }
  if (state.mediaRecorder?.state === "recording") return;
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    state.audioChunks = [];
    state.mediaRecorder = new MediaRecorder(stream);
    state.mediaRecorder.ondataavailable = (event) => state.audioChunks.push(event.data);
    state.mediaRecorder.onstop = () => {
      const blob = new Blob(state.audioChunks, { type: "audio/webm" });
      const reader = new FileReader();
      reader.onloadend = () => {
        state.currentAudio = reader.result;
        $("audioPlayer").src = state.currentAudio;
      };
      reader.readAsDataURL(blob);
      stream.getTracks().forEach((track) => track.stop());
    };
    state.mediaRecorder.start();
    $("recordingState").textContent = "Gravando...";
    $("startRecordBtn").disabled = true;
    $("pauseRecordBtn").disabled = false;
    $("stopRecordBtn").disabled = false;
  } catch (error) {
    alert(`Não foi possível gravar: ${error.message}`);
  }
}

function pauseRecording() {
  if (state.mediaRecorder?.state === "recording") {
    state.mediaRecorder.pause();
    $("recordingState").textContent = "Pausado";
    $("pauseRecordBtn").textContent = "Retomar";
    return;
  }
  if (state.mediaRecorder?.state === "paused") {
    state.mediaRecorder.resume();
    $("recordingState").textContent = "Gravando...";
    $("pauseRecordBtn").textContent = "Pausar";
  }
}

function stopRecording() {
  if (state.mediaRecorder && state.mediaRecorder.state !== "inactive") {
    state.mediaRecorder.stop();
    $("recordingState").textContent = "Áudio finalizado";
    $("startRecordBtn").disabled = false;
    $("pauseRecordBtn").disabled = true;
    $("stopRecordBtn").disabled = true;
    $("pauseRecordBtn").textContent = "Pausar";
  }
}

function simulateTranscription() {
  $("recordingTranscript").value = "Transcrição simulada: reunião registrada com discussão sobre organização da rotina, alinhamento de fluxos, definição de prioridades, responsabilidades e prazos para os encaminhamentos.";
}

function buildRecordingSummary() {
  const activity = state.activities.find((item) => item.id === $("recordingActivitySelect").value);
  return buildActivitySummary(activity || formToActivity(), $("recordingTranscript").value);
}

async function saveRecording() {
  const recording = {
    id: uid("rec"),
    activity_id: $("recordingActivitySelect").value,
    user_id: "local-user",
    audio_url: state.currentAudio,
    transcript: $("recordingTranscript").value.trim(),
    ai_summary: $("recordingSummary").value.trim(),
    status: $("recordingTranscript").value.trim() ? "transcrita" : "pendente",
    created_at: new Date().toISOString(),
  };
  state.recordings.unshift(recording);
  persist();
  try {
    await saveCloudRecording(recording);
  } catch (error) {
    console.warn("Recording saved locally only:", error.message);
  }
  $("recordingTranscript").value = "";
  $("recordingSummary").value = "";
  $("audioPlayer").removeAttribute("src");
  state.currentAudio = "";
  renderAll();
}

function fillRecording(recording) {
  $("recordingActivitySelect").value = recording.activity_id;
  $("audioPlayer").src = recording.audio_url || "";
  $("recordingTranscript").value = recording.transcript || "";
  $("recordingSummary").value = recording.ai_summary || "";
  setView("gravacoes");
}

function buildActivitySummary(activity, transcript = "") {
  const unit = state.units.find((item) => item.id === activity?.unit_id);
  return [
    "Resumo da atividade",
    `Data: ${formatDate(activity?.date || today())}`,
    `Local: ${activity?.location || "Não informado"}`,
    `Tipo de atividade: ${activity?.type || "Não informado"}`,
    `Participantes: ${activity?.participants || "Não informado"}`,
    `Objetivo: ${activity?.objective || "Não informado"}`,
    `Principais pontos discutidos: ${activity?.main_points || transcript || activity?.description || "Não informado"}`,
    `Encaminhamentos: ${activity?.referrals || "Sem encaminhamentos registrados"}`,
    `Responsáveis: ${activity?.responsible_people || "Não informado"}`,
    `Prazos: ${activity?.deadlines || "Não informado"}`,
    `Observações técnicas: ${activity?.observations || `Registro vinculado à ${unit?.name || "operação"}, com finalidade de memória executiva, produtividade e acompanhamento institucional.`}`,
  ].join("\n");
}

function buildInstitutionalReport() {
  const period = $("reportPeriod").value;
  const type = $("reportTypeFilter").value;
  const activities = state.activities.filter((activity) => type === "todos" || activity.type === type);
  const start = activities.map((a) => a.date).sort()[0] || today();
  const end = activities.map((a) => a.date).sort().at(-1) || today();
  return [
    "RELATÓRIO DE ATIVIDADES — LUMYX",
    "",
    `Período: ${period.toUpperCase()} - ${formatDate(start)} a ${formatDate(end)}`,
    "Responsável: Gestão operacional",
    "Setor: Operações / Produtividade",
    "",
    "1. Introdução",
    "O presente relatório tem por objetivo registrar atividades, decisões, encaminhamentos e resultados operacionais, subsidiando memória institucional, acompanhamento de produtividade e tomada de decisão.",
    "",
    "2. Atividades realizadas",
    activities.length ? activities.map((a) => `- ${formatDate(a.date)} | ${a.location || "Local não informado"} | ${a.type} | ${a.title}. Participantes: ${a.participants || "não informado"}. Descrição: ${a.description || a.objective || "sem descrição detalhada"}.`).join("\n") : "Não foram localizadas atividades para os filtros selecionados.",
    "",
    "3. Principais encaminhamentos",
    activities.map((a) => a.referrals).filter(Boolean).map((item) => `- ${item}`).join("\n") || "Não há encaminhamentos registrados no período.",
    "",
    "4. Resultados/produtos gerados",
    `Foram registradas ${activities.length} atividade(s), incluindo reuniões, articulações, acompanhamentos, documentos e organização de fluxos conforme os filtros aplicados.`,
    "",
    "5. Pendências",
    activities.filter((a) => ["pendente", "em andamento", "planejada"].includes(a.status)).map((a) => `- ${a.title}: ${a.deadlines || "prazo não informado"}.`).join("\n") || "Não há pendências registradas.",
    "",
    "6. Considerações técnicas",
    "As ações descritas contribuem para melhoria da organização operacional, clareza de responsabilidades, acompanhamento de prazos, rastreabilidade das decisões e ganho de produtividade institucional.",
    "",
    "7. Conclusão",
    "Encaminha-se o presente relatório para registro institucional e providências administrativas cabíveis.",
  ].join("\n");
}

function buildSingleActivityReport(activity) {
  return [
    "RELATÓRIO DE ATIVIDADE — LUMYX",
    "",
    buildActivitySummary(activity),
    "",
    "Texto técnico institucional:",
    `A atividade "${activity.title}" foi registrada no LUMYX, com finalidade de organizar rotina, consolidar memória institucional, acompanhar ações pactuadas e apoiar a geração de relatórios executivos.`,
  ].join("\n");
}

async function copyReport() {
  await navigator.clipboard.writeText($("reportOutput").value);
  $("copyReportBtn").textContent = "Copiado";
  setTimeout(() => $("copyReportBtn").textContent = "Copiar texto", 1200);
}

async function saveReport() {
  const content = $("reportOutput").value.trim() || buildInstitutionalReport();
  const report = {
    id: uid("rep"),
    user_id: "local-user",
    title: "Relatório de atividades - LUMYX",
    period_start: today(),
    period_end: today(),
    filters: { period: $("reportPeriod").value, type: $("reportTypeFilter").value },
    content,
    type: "relatório institucional",
    created_at: new Date().toISOString(),
  };
  state.reports.unshift(report);
  persist();
  try {
    await saveCloudReport(report);
  } catch (error) {
    console.warn("Report saved locally only:", error.message);
  }
  renderAll();
}

function exportData() {
  const blob = new Blob([localStorage.getItem(STORE_KEY)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "lumyx-dados.json";
  link.click();
  URL.revokeObjectURL(url);
}

async function importData(event) {
  const file = event.target.files[0];
  if (!file) return;
  const data = JSON.parse(await file.text());
  state.activities = data.activities || [];
  state.units = data.units || [];
  state.recordings = data.recordings || [];
  state.reports = data.reports || [];
  state.demands = data.demands || [];
  persist();
  renderAll();
}

function updateLogo(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    document.querySelectorAll(".logo-mark").forEach((mark) => {
      mark.innerHTML = `<img src="${reader.result}" alt="Logo LUMYX">`;
    });
  };
  reader.readAsDataURL(file);
}

function formatDate(value) {
  if (!value) return "Não informado";
  const [year, month, day] = value.slice(0, 10).split("-");
  return `${day}/${month}/${year}`;
}

function escapeHtml(value = "") {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

init();
