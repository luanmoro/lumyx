window.LUMYX_CONFIG = {
  supabaseUrl: "https://uouiqsvcimubdkyxymhb.supabase.co",
  supabaseAnonKey: "sb_publishable__hXCZd8e2mB_y2XC8F_3Iw_iRDvvTVZ",
  demoEmail: "admin@lumyx.local",
  demoPassword: "123456",
};
